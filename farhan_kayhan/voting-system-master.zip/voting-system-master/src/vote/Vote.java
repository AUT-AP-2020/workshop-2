package vote;

import ir.huri.jcal.JalaliCalendar;
import java.util.GregorianCalendar;
import java.util.Objects;

/**
 * the vote class
 * @author hadi
 * @version 1.0
 */

public class Vote {
    private Person person;
    private JalaliCalendar date;

    /**
     * constructor for Vote class to create a vote object
     * @param person person who voted
     */
    public Vote(Person person) {
        this.person = person;
        this.date = new JalaliCalendar(new GregorianCalendar());
    }

    @Override
    public String toString() {
        return "person:" + person.toString() +
                ", date:" + date.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vote vote = (Vote) o;
        return Objects.equals(person, vote.person) &&
                Objects.equals(date, vote.date);
    }

    @Override
    public int hashCode() {
        return Objects.hash(person, date);
    }
}
