package vote;

import java.util.Objects;

/**
 * The person class
 * @author hadi
 * @version 1.02
 */

public class Person {
    private String firstName;
    private String lastName;

    /**
     * constructor for Person class
     * @param firstName person first name
     * @param lastName person last name
     */
    public Person(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    @Override
    public String toString() {
        return firstName+" "+lastName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return Objects.equals(firstName, person.firstName) &&
                Objects.equals(lastName, person.lastName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(firstName, lastName);
    }
}
