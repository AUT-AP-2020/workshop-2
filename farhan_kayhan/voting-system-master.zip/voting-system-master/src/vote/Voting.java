package vote;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * The voting class
 * @author hadi
 * @version 1.01
 */
public class Voting {
    private int type;
    private String question;
    private ArrayList<Person> voters;
    private HashMap<Integer, HashSet<Vote>> polls;
    private ArrayList<String> pollsChoices;
    private int pollNum;

    /**
     * constructor for Voting class
     * @param type voting type
     * @param question voting question
     */
    public Voting(int type, String question) {
        this.type = type;
        this.question = question;
        this.voters = new ArrayList<Person>();
        polls = new HashMap<Integer, HashSet<Vote>>();
        pollsChoices = new ArrayList<String>();
        this.pollNum = 0;
    }

    /**
     * add new  choice to the current voting
     * @param poll new choice
     */
    public void createPoll(String poll) {
        pollsChoices.add(poll);
        polls.put(pollNum, new HashSet<Vote>());
        pollNum++;
    }

    /**
     * submit a vote with given details
     * @param voter voter person
     * @param votes list of selected choice
     */
    public void vote(Person voter, ArrayList<String> votes) {
        if (!voters.contains(voter)) {
            voters.add(voter);
            for (String vote : votes) {
                int index = pollsChoices.indexOf(vote);
                polls.get(index).add(new Vote(voter));
            }
        } else {
            System.out.println("he has already voted");
        }
    }

    /**
     * print current voting result
     */
    public void getResult() {
        System.out.println(question);
        for (int i = 0; i < pollsChoices.size(); i++)
            System.out.println(i + 1
                    + ") " + pollsChoices.get(i)
                    + " number of vote: "
                    + polls.get(i).size());
    }

    /**
     * getter for current voting question
     * @return current voting question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * print current voting votes
     */
    public void printVotes() {
        for (int i = 0; i < pollNum; i++) {
            System.out.println(i + 1 + ") " + pollsChoices.get(i));
            if (polls.get(i).size() != 0)
                System.out.println(polls.get(i));
            else
                System.out.println("[no vote!]");
        }
    }

    /**
     * return current voting type
     * @return current voting type
     */
    public int getType() {
        return type;
    }

    /**
     * print current voting choices
     */
    public void getPolls() {
        for (int i = 1; i <= pollsChoices.size(); i++)
            System.out.println(i + ") " + pollsChoices.get(i - 1));
    }

    /**
     * getter for list of poll choices
     * @return  list of poll choices
     */
    public ArrayList<String> getPollsChoices() {
        return pollsChoices;
    }
}
