package vote;


import java.util.*;

/**
 * The Main class
 * @author hadi
 * @version 1.01
 */
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        VotingSystem votingSystem = new VotingSystem();
        while (true) {
            String tmpEnter = null;
            System.out.println("1)create new voting\n2)select a voting\n3)exit");
            switch (input.nextInt()) {
                case 1:
                    String question;
                    int type;
                    ArrayList<String> Polls = new ArrayList<String>();
                    System.out.println("enter the question");
                    tmpEnter = input.nextLine();
                    question = input.nextLine();
                    System.out.println("please choose an option\n1)single voting\n2)multi voting");
                    type = input.nextInt() - 1;
                    while (true) {
                        System.out.println("enter poll 0 to end");
                        String tmp = input.next();
                        if (tmp.equals("0"))
                            break;
                        Polls.add(tmp);
                    }
                    votingSystem.createVoting(question, type, Polls);
                    System.out.println("poll successful created");
                    break;
                case 2:
                    int selectedVotingNum;
                    ArrayList<String> polls = new ArrayList<String>();
                    System.out.println("please select a vote");
                    votingSystem.getVotingList();
                    selectedVotingNum = input.nextInt() - 1;
                    Voting selectedVoting = votingSystem.getVoteList().get(selectedVotingNum);
                    while (true) {
                        System.out.println("1)vote\n2)get result\n3)get votes\n4)main menu");
                        int option = input.nextInt();
                        if (option == 4)
                            break;
                        switch (option) {
                            case 1:
                                String firstName;
                                String lastName;
                                polls.clear();
                                System.out.println("enter first name");
                                firstName = input.next();
                                System.out.println("enter last name");
                                lastName = input.next();
                                if (selectedVoting.getType() == 1)
                                    while (true) {
                                        int selectedPoll = 0;
                                        System.out.println("select a poll or enter 0 to confirm");
                                        selectedVoting.getPolls();
                                        selectedPoll = input.nextInt() - 1;
                                        if (selectedPoll == -1) {
                                            break;
                                        } else {
                                            polls.add(selectedVoting.getPollsChoices().get(selectedPoll));
                                        }
                                    }
                                else {
                                    int selectedPoll;
                                    System.out.println("select a poll");
                                    selectedVoting.getPolls();
                                    selectedPoll = input.nextInt() - 1;
                                    polls.add(selectedVoting.getPollsChoices().get(selectedPoll));
                                }
                                votingSystem.vote(selectedVotingNum, new Person(firstName, lastName), polls);
                                System.out.println("voting successful finished");
                                break;
                            case 2:
                                votingSystem.getResult(selectedVotingNum);
                                break;
                            case 3:
                                votingSystem.getVoteList().get(selectedVotingNum).printVotes();
                                break;
                            default:
                                break;
                        }
                    }
                    break;
                case 3:
                    System.out.println("Good Bye :)");
                    System.exit(0);
                    break;
                default:
                    System.out.println("invalid option");
                    break;
            }
        }
    }
}
