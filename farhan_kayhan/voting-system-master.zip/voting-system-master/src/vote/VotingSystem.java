package vote;

import java.util.ArrayList;

/**
 * The votingSystem class
 * @author hadi
 * @version 1.01
 */
public class VotingSystem {
    private ArrayList<Voting> voteList;

    /**
     * constructor for VotingSystem Class
     */
    public VotingSystem() {

        this.voteList = new ArrayList<Voting>();
    }

    /**
     * it is create new voting with given details
     * @param question new voting question
     * @param type new voting type if type=0 -> single voting mode if type =1 multi voting mode
     * @param poll an ArrayList of voting choices
     */
    public void createVoting(String question, int type, ArrayList<String> poll) {
        Voting tmp = new Voting(type, question);
        for (String Tmp : poll)
            tmp.createPoll(Tmp);
        voteList.add(tmp);
    }

    /**
     * submit a vote with given details
     * @param vote index of voting in ArrayList
     * @param voter person who voted
     * @param votes a list of vote
     */
    public void vote(int vote, Person voter, ArrayList<String> votes) {
        if ((voteList.get(vote).getType() == 0 && votes.size() == 1) || voteList.get(vote).getType() == 1)
            voteList.get(vote).vote(voter, votes);
        else
            System.out.println("multi voting isn't allowed");
    }

    /**
     * print a voting result
     * @param index index of considered voting
     */
    public void getResult(int index) {
        voteList.get(index).getResult();
    }

    /**
     * print all active voting in current voting system
     */
    public void getVotingList() {
        for (int i = 1; i <= voteList.size(); i++)
            System.out.println(i + ")" + voteList.get(i - 1).getQuestion());
    }

    /**
     * getter for voting ArrayList
     * @return voting ArrayList
     */
    public ArrayList<Voting> getVoteList() {
        return voteList;
    }
}
