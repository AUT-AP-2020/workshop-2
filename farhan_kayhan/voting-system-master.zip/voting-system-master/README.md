it is simple voting system


