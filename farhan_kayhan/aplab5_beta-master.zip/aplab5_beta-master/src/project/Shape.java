package project;

public interface Shape {
    double calculatePerimeter();
    double calculateArea();
    void draw();
    boolean equals(Object obj);
    String toString();
}
