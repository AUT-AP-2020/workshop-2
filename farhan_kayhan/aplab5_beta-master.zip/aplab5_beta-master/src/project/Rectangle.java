package project;

import java.util.Arrays;

public class Rectangle extends Polygon{

    public Rectangle(int... sides) {
        super(sides);
    }

    @Override
    public double calculateArea() {
        return sides.get(1) * sides.get(0);
    }

    public boolean isSquare() {
        return (sides.get(1).equals(sides.get(0)));
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "sides=" + sides +
                '}';
    }

    public void draw() {
        System.out.println("Rectangle->  perimeter= " + calculatePerimeter() + " | area= " + calculateArea());
    }

}
