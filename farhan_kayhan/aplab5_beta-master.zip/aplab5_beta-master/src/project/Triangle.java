package project;

import java.util.Arrays;

public class Triangle extends Polygon{
    public Triangle(int... sides) {
        super(sides);
    }

    @Override
    public double calculateArea() {
        Double[] p = {0D};
        sides.forEach((value)-> p[0] +=value);
        p[0]/=2;
        double A = Math.sqrt(p[0] * (p[0] - sides.get(0)) * (p[0] - sides.get(1)) * (p[0] - sides.get(2)));
        return A;
    }

    public boolean isEquilateral() {
        return (sides.get(0).equals(sides.get(1)) && sides.get(0).equals(sides.get(2)));
    }

    public void draw() {
        System.out.println("Triangle->  perimeter= " + calculatePerimeter() + " | area= " + calculateArea());
    }

    @Override
    public String toString() {
        return "Triangle{" +
                "sides=" + sides +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
