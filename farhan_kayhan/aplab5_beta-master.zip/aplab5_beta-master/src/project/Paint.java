package project;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Paint {
    private ArrayList<Shape> shapes;
    public Paint(){
        shapes= new ArrayList<>();
    }
    public void addShape(Shape shape){
        shapes.add(shape);
    }
    public void drawAll(){
        for (Shape tmp: shapes)
            tmp.draw();
    }
    public void printAll(){
        for (Shape tmp: shapes)
            System.out.println(tmp.toString());
    }
    public void describeEqualSides(){
        System.out.println("equals sides shapes:");
        for (Shape tmp: shapes) {
            if (tmp instanceof Triangle){
                if (((Triangle) tmp).isEquilateral())
                    System.out.println(tmp.toString());
            } else if (tmp instanceof Rectangle){
                if (((Rectangle) tmp).isSquare())
                    System.out.println(tmp.toString());
            }
        }
    }
}
