package project;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Objects;

public class Polygon implements Shape {
    protected ArrayList<Integer> sides;

    public Polygon(int... sides) {
        this.sides = new ArrayList<Integer>();
        for (int tmp : sides)
            this.sides.add(tmp);

    }

    public ArrayList<Integer> getSides() {
        return sides;
    }
    @Override
    public final double calculatePerimeter() {
        Double[] perimeter = {0D};
        sides.forEach((value)-> perimeter[0] +=value);
        return perimeter[0];
    }

    @Override
    public double calculateArea() {
        return 0;
    }

    @Override
    public void draw() {
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Polygon polygon = (Polygon) o;
        return Objects.equals(sides, polygon.sides);
    }

}
