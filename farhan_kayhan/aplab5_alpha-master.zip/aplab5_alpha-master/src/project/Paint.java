package project;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Paint {
    private ArrayList<Circle> circles;
    private ArrayList<Triangle> triangles;
    private ArrayList<Rectangle> rectangles;
    public Paint(){
        circles= new ArrayList<>();
        triangles= new ArrayList<>();
        rectangles= new ArrayList<>();
    }
    public void addCircle(Circle toAdd){
        circles.add(toAdd);
    }
    public void addTriangle(Triangle toAdd){
        triangles.add(toAdd);
    }
    public void addRectangle(Rectangle toAdd){
        rectangles.add(toAdd);
    }
    public void drawAll(){
        for (Circle tmp: circles)
            tmp.draw();
        for (Triangle tmp: triangles)
            tmp.draw();
        for (Rectangle tmp : rectangles)
            tmp.draw();
    }
    public void printAll(){
        for (Circle tmp: circles)
            System.out.println(tmp.toString());
        for (Triangle tmp: triangles)
            System.out.println(tmp.toString());
        for (Rectangle tmp : rectangles)
            System.out.println(tmp.toString());
    }
}
