package project;

import java.util.Arrays;

public class Rectangle {
    int[] sides;

    public Rectangle(int... sides) {
        this.sides = new int[2];
        int i = 0;
        for (int tmp : sides) {
            this.sides[i] = tmp;
            i++;
        }
    }

    public double calculatePerimeter() {
        return 2 * (sides[0] + sides[1]);
    }

    public double calculateArea() {
        return sides[0] * sides[1];
    }

    public boolean isSquare() {
        return (sides[0] == sides[1]);
    }

    public int[] getSides() {
        return sides;
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "sides=" + Arrays.toString(sides) +
                '}';
    }

    public void draw() {
        System.out.println("Rectangle->  perimeter= " + calculatePerimeter() + " | area= " + calculateArea());
    }

}
